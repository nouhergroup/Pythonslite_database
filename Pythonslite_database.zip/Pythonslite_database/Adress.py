# GUIBasic2-Expense.py
from tkinter import *
from tkinter import ttk, messagebox
import csv
from datetime import datetime


#########################Dadabase#########################

import sqlite3
conn = sqlite3.connect('alladress.sqlite3')


c = conn.cursor()
c.execute("""CREATE TABLE IF NOT EXISTS alladress(
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                transactionid TEXT,
                datetime TEXT,
                name TEXT,
                lastnamme TEXT,
                position TEXT,
                Date_of_birth TEXT,
                Adress TEXT,
                tel TEXT

                )""")

def insert_alladress(transactionid,datetime,name,lastnamme,position,Date_of_birth,Adress,tel):
    ID = None
    with conn:
        c.execute(""" INSERT INTO alladress VALUES (?,?,?,?,?,?,?,?,?)""",
            (ID,transactionid,datetime,name,lastnamme,position,Date_of_birth,Adress,tel))
        conn.commit()
       # print('Insert Succes')

def show_alladress():
    with conn:
        c.execute("SELECT * FROM alladress")
        all_adress = c.fetchall()
        #print(all_adress)
    return all_adress

def update_alladress(transactionid,name,lastnamme,position,Date_of_birth,Adress,tel):
    with conn:
        c.execute("""UPDATE alladress SET name=?,lastnamme=?,position=?,Date_of_birth=?,Adress=?,tel=? WHERE transactionid=? """,
            ([name,lastnamme,position,Date_of_birth,Adress,tel,transactionid]))
        conn.commit()
      #  print('Data Update')

def delete_alladress(transactionid):
    with conn:
        c.execute("DELETE FROM alladress WHERE transactionid=?",([transactionid]))
    conn.commit()
    #print('Data Delete')

##################################################

GUI = Tk()
GUI.title('Develop by Uncle Media')

w = 1250
h = 700

ws = GUI.winfo_screenwidth() 
hs = GUI.winfo_screenheight() 


x = (ws/2) - (w/2)
y = (hs/2) - (h/2) - 100

GUI.geometry(f'{w}x{h}+{x:.0f}+{y:.0f}')


#########################MENU#########################

menubar = Menu(GUI)
GUI.config(menu=menubar)

#file menu
filemenu = Menu(menubar,tearoff=0)
menubar.add_cascade(label='file',menu=filemenu)
filemenu.add_command(label='import CSV')
filemenu.add_command(label='import to googlesheet')


#Help
def About():
    messagebox.showinfo('About','You can suport Ours in \nBangkok Bank Account\n สาขา 0109 สะพานขาว \nบัญชีเลขที่ 109-0-77222-7\n ชื่อMR NOUHER HA')

donatemenu = Menu(menubar,tearoff=0)
menubar.add_cascade(label='Donate',menu=donatemenu)
donatemenu.add_command(label='suport',command=About)

#Donate
def Help():
    messagebox.showinfo('About','You can contact ours\nunclemedia0@gmail.com\nfacebookpage:@unclemedia0\nTel:0655744765')
helpmenu = Menu(menubar,tearoff=0)
menubar.add_cascade(label='Help',menu=helpmenu)
helpmenu.add_command(label='Socail media',command=Help)



##################################################

Tab = ttk.Notebook(GUI)
T1 = Frame(Tab)
T2 = Frame(Tab)
Tab.pack(fill=BOTH,expand=1)

icon_1 = PhotoImage(file='t1_money.png')
icon_2 = PhotoImage(file='t2_story.png')



Tab.add(T1, text=f'{"Add":^{30}}',image=icon_1,compound='top')
Tab.add(T2, text=f'{"Story":^{30}}',image=icon_2,compound='top')




F1 = Frame(T1)
F1.pack()

days = {'Mon':'Mon',
        'Tue':'Tue',
        'Wed':'Wed',
        'Thu':'Thu',
        'Fri':'Fri',
        'Sat':'Set',
        'Sun':'Sun'}

def Save(event=None):
    name = Name_note.get()
    lastname = Lastname_note.get()
    Position = position_note.get()
    Date_of_birth = date_of_birth_note.get()
    Adress = adress_note.get()
    tel = Tel_note.get()
    if name =='':
        # print('No! Data')
        messagebox.showwarning('ERROR','Plase Enter Name')
        return
    elif lastname == '':
        messagebox.showwarning('ERROR','Plase Enter Lastname')
        return
    elif Position == '':
        messagebox.showwarning('ERROR','Plase Enter Position')
        return

    elif Date_of_birth == '':
        messagebox.showwarning('ERROR','Plase Enter Date_of_birth')
        return

    elif Adress == '':
        messagebox.showwarning('ERROR','Plase Enter Adress')
        return

    elif tel == '':
        tel = 'None'

    try:
        #print('Name: {} Lastname: {} Position:{} Date_of_birth:{} Adress:{} Tel:{} '.format(name,lastname,Position,Date_of_birth,Adress,tel))
        text = 'Succes'
        v_result.set(text)
        Name_note.set('')
        Lastname_note.set('')
        position_note.set('')
        date_of_birth_note.set('')
        adress_note.set('')
        Tel_note.set('')
        today = datetime.now().strftime('%a') 
        #print(today)
        stamp = datetime.now()
        dt = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        transactionid = stamp.strftime('%Y%m%M%f')
        dt = days[today] + '-' + dt

        insert_alladress(transactionid,dt,name,lastname,Position,Date_of_birth,Adress,tel)





        with open('AdressCSV.csv','a',encoding='utf-8',newline='') as f:
            fw = csv.writer(f) 
            data = [transactionid,dt,name,lastname,Position,Date_of_birth,Adress,tel]
            fw.writerow(data)


        E1.focus()
        update_table()
    except Exception as e:
        print("ERROR:",e)
        messagebox.showwarning('ERROR','Enter new data')
        Name_note.set('')
        Lastname_note.set('')
        position_note.set('')
        date_of_birth_note.set('')
        adress_note.set('')
        Tel_note.set('')

GUI.bind('<Return>',Save) 

FONT1 = ('Phetsarath OT',18) 


centerimg = PhotoImage(file='t3_save.png').subsample(20)
logo = Label(F1,image=centerimg)
logo.pack()

#------text1--------
L = Label(F1,text='Name:',font=FONT1).pack()
Name_note = StringVar()

E1 = Entry(F1,textvariable=Name_note,font=FONT1)
E1.pack()
#-------------------
 
#------text2--------
L = Label(F1,text='Lastname:',font=FONT1).pack()
Lastname_note = StringVar()
# StringVar() คือ ตัวแปรพิเศษสำหรับเก็บข้อมูลใน GUI
E2 = Entry(F1,textvariable=Lastname_note,font=FONT1)
E2.pack()
#-------------------

#------text3--------
L = Label(F1,text='Position:',font=FONT1).pack()
position_note = StringVar()

E3 = Entry(F1,textvariable=position_note,font=FONT1)
E3.pack()

#------text4--------
L = Label(F1,text='Date of birth:',font=FONT1).pack()
date_of_birth_note = StringVar()

E4 = Entry(F1,textvariable=date_of_birth_note,font=FONT1)
E4.pack()

#------text5--------
L = Label(F1,text='Adress:',font=FONT1).pack()
adress_note = StringVar()

E5 = Entry(F1,textvariable=adress_note,font=FONT1)
E5.pack()

#------text6--------
L = Label(F1,text='Tel:',font=FONT1).pack()
Tel_note = StringVar()

E6 = Entry(F1,textvariable=Tel_note,font=FONT1)
E6.pack()

#------text7--------
L = Label(F1,text='Salary:',font=FONT1).pack()
Tel_note = StringVar()

E7 = Entry(F1,textvariable=Tel_note,font=FONT1)
E7.pack()
#-------------------

saveicon = PhotoImage(file='t4.png').subsample(20)

#-------------------
icon_3 = PhotoImage(file='t3_save.png')
B2 = Button(F1,text='Save',image=icon_3,compound='top',command=Save)
B2.pack(ipadx=30,ipady=10,padx=10,pady=20)

v_result = StringVar()
v_result.set('------Result----')
result = Label(F1,textvariable=v_result,font=FONT1,fg='green')
result.pack(pady=20)

############# Tab2 ####################

#######################TAB2################################
def read_csv():
    with open('saveadress.csv',newline='',encoding='utf-8') as f:
        fr = csv.reader(f)
        data = list(fr)

    return data


#########Table###########

L = Label(T2,text='Table Result data:',font=FONT1).pack()

header = ['ID','Date-time','Name','Lastname','Position','Date of birth','Adress','Tel']
resulttable = ttk.Treeview(T2,column=header,show='headings',height=10)
resulttable.pack()

for i in range(len(header)):
    resulttable.heading(header[i],text=header[i])
for h in header:
    resulttable.heading(h,text=h)
headerwidth = [150,180,100,100,100,100,300,120]

for h,w in zip(header,headerwidth):
    resulttable.column(h,width=w)




alltransaction = {}


def UpdateCSV():
    with open('AdressCSV.csv','w',newline='',encoding='utf-8') as f:
        fw = csv.writer(f)
        data = list(alltransaction.values())
        fw.writerows(data)
        #print('Table was updated')
        
def UpdateSQL():
    data = list(alltransaction.values())
    for d in data:
        update_alladress(d[0],d[2],d[3],d[4],d[5],d[6],d[7])

def DeleteRecord(event=None):
    check = messagebox.askyesno('Confirm?','Are you sure?')
    #print('YES/NO:',check)

    if check == True:
        #print('delete')
        select = resulttable.selection()

        data = resulttable.item(select)
        data = data['values']
        transactionid = data[0]
        del alltransaction[str(transactionid)] 
        delete_alladress(str(transactionid))
        update_table()
    else:
        #print('cancel')
        pass

BDelete = ttk.Button(T2,text='Delete',command=DeleteRecord)
BDelete.place(x=50,y=550)

resulttable.bind('<F1>',DeleteRecord)

def update_table():
    resulttable.delete(*resulttable.get_children())
    try:
        data = show_alladress()
        for d in data:
            alltransaction[d[1]] = d[1:] 
            resulttable.insert('',0,value=d[1:])
    except Exception as e:
        print('No File')
        print('ERROR:',e)

#### Right Click Menu ####

def EditRecord():
    POPUP = Toplevel()
    POPUP.title('EditRecord')
    w = 500
    h = 600
    ws = POPUP.winfo_screenwidth() 
    hs = POPUP.winfo_screenheight() 
    x = (ws/2) - (w/2)
    y = (hs/2) - (h/2) - 100
    POPUP.geometry(f'{w}x{h}+{x:.0f}+{y:.0f}')

    #------text1--------
    L = Label(POPUP,text='Name:',font=FONT1).pack()
    Name_note = StringVar()
    E1 = Entry(POPUP,textvariable=Name_note,font=FONT1)
    E1.pack()
    #-------------------
     
    #------text2--------
    L = Label(POPUP,text='Lastname:',font=FONT1).pack()
    Lastname_note = StringVar()
    E2 = Entry(POPUP,textvariable=Lastname_note,font=FONT1)
    E2.pack()
    #-------------------

    #------text3--------
    L = Label(POPUP,text='Position:',font=FONT1).pack()
    position_note = StringVar()
    E3 = Entry(POPUP,textvariable=position_note,font=FONT1)
    E3.pack()

    #------text4--------
    L = Label(POPUP,text='Date of birth:',font=FONT1).pack()
    date_of_birth_note = StringVar()
    E4 = Entry(POPUP,textvariable=date_of_birth_note,font=FONT1)
    E4.pack()

    #------text5--------
    L = Label(POPUP,text='Adress:',font=FONT1).pack()
    adress_note = StringVar()
    E5 = Entry(POPUP,textvariable=adress_note,font=FONT1)
    E5.pack()

    #------text6--------
    L = Label(POPUP,text='Tel:',font=FONT1).pack()
    Tel_note = StringVar()
    E6 = Entry(POPUP,textvariable=Tel_note,font=FONT1)
    E6.pack()
    #-------------------

    def Edit():
        olddata =  alltransaction[str(transactionid)]
        #print('OLD:',olddata)
        n = Name_note.get()
        l  = Lastname_note.get()
        p = position_note.get()
        c = date_of_birth_note.get()
        v = adress_note.get()
        t = Tel_note.get()
        newdata = [olddata[0],olddata[1],n,l,p,c,v,t]
        alltransaction[str(transactionid)] = newdata
        UpdateSQL()
        update_table()
        POPUP.destroy()


    saveicon = PhotoImage(file='t4.png').subsample(20)
    B2 = Button(POPUP,text=f'{"Save": >{10}}',image=saveicon,compound='left', command=Edit)
    B2.pack(ipadx=50,ipady=20,pady=20)
    select = resulttable.selection()
    #print(select)
    data = resulttable.item(select)
    data = data['values']
    #print(data)
    transactionid = data[0]
    Name_note.set(data[2])
    Lastname_note.set(data[3])
    position_note.set(data[4])
    date_of_birth_note.set(data[5])
    adress_note.set(data[6])
    Tel_note.set(data[7])


    POPUP.mainloop()


rightclick = Menu(GUI,tearoff=0)
rightclick.add_command(label='Edite',command=EditRecord)
rightclick.add_command(label='Delete',command=DeleteRecord)


def popup(event):
    rightclick.post(event.x_root,event.y_root)

resulttable.bind('<Button-2>',popup)

update_table()
GUI.bind('<Tab>',lambda x: E2.focus())
GUI.mainloop()